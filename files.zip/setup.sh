#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# Marathon Homes Portal – Quick Setup Script
# Paste this entire block into Git Bash and press Enter.
# It will: create the project folder, write index.html,
# init a git repo, and open the file in your browser.
# ─────────────────────────────────────────────────────────────

set -e

PROJECT_DIR="$HOME/Downloads/marathon-homes-portal"

echo "→ Creating project directory at $PROJECT_DIR"
mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"

echo "→ Initializing git repository"
git init -q

echo "→ Writing index.html"
cat > index.html << 'HTMLEOF'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Marathon Homes – Operations Portal</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet" />
  <style>
    :root {
      --bg:#2B2B2B;--bg-card:#323232;--bg-deep:#1F1F1F;
      --green:#8DC63F;--green-dim:#6FA030;--green-glow:rgba(141,198,63,0.15);
      --white:#FFFFFF;--gray-1:#C8C8C8;--gray-2:#7A7A7A;--gray-3:#444444;
      --radius:6px;--shadow:0 4px 24px rgba(0,0,0,0.5);
    }
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{background:var(--bg);color:var(--white);font-family:'Barlow',sans-serif;font-size:15px;min-height:100vh}
    header{background:var(--bg-deep);border-bottom:2px solid var(--green);padding:0 32px;display:flex;align-items:center;justify-content:space-between;height:72px;position:sticky;top:0;z-index:100;box-shadow:var(--shadow)}
    .logo{display:flex;align-items:center;gap:14px;text-decoration:none;user-select:none}
    .logo-icon{width:44px;height:44px;flex-shrink:0}
    .logo-text{display:flex;flex-direction:column;line-height:1}
    .logo-text .marathon{font-family:'Barlow Condensed',sans-serif;font-weight:800;font-size:26px;letter-spacing:.12em;color:var(--white);text-transform:uppercase}
    .logo-text .homes{font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:13px;letter-spacing:.35em;color:var(--green);text-transform:uppercase;margin-top:1px}
    .header-meta{font-size:12px;color:var(--gray-2);text-align:right;line-height:1.6}
    .header-meta strong{color:var(--green);font-weight:600}
    .tab-bar-wrapper{background:var(--bg-deep);border-bottom:1px solid var(--gray-3);overflow-x:auto;scrollbar-width:none}
    .tab-bar-wrapper::-webkit-scrollbar{display:none}
    .tab-bar{display:flex;padding:0 20px;min-width:max-content}
    .tab-btn{display:flex;align-items:center;gap:7px;padding:0 18px;height:46px;background:none;border:none;border-bottom:3px solid transparent;color:var(--gray-2);font-family:'Barlow Condensed',sans-serif;font-weight:600;font-size:13px;letter-spacing:.08em;text-transform:uppercase;cursor:pointer;transition:color .18s,border-color .18s,background .18s;white-space:nowrap}
    .tab-btn:hover{color:var(--gray-1);background:rgba(255,255,255,.03)}
    .tab-btn.active{color:var(--green);border-bottom-color:var(--green);background:rgba(141,198,63,.06)}
    .main{padding:32px 32px 64px;max-width:1400px;margin:0 auto}
    .tab-panel{display:none}.tab-panel.active{display:block}
    .panel-header{display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid var(--gray-3)}
    .panel-title{font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:28px;letter-spacing:.05em;color:var(--white)}
    .panel-title span{color:var(--green)}
    .panel-subtitle{font-size:13px;color:var(--gray-2);margin-top:3px}
    .btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:var(--radius);font-family:'Barlow',sans-serif;font-size:13px;font-weight:600;cursor:pointer;border:none;transition:all .15s}
    .btn-primary{background:var(--green);color:var(--bg-deep)}.btn-primary:hover{background:#a0d94a}
    .btn-ghost{background:transparent;color:var(--gray-1);border:1px solid var(--gray-3)}.btn-ghost:hover{border-color:var(--green);color:var(--green)}
    .btn-row{display:flex;gap:8px;flex-wrap:wrap}
    .card{background:var(--bg-card);border:1px solid var(--gray-3);border-radius:var(--radius);padding:20px 24px;margin-bottom:20px}
    .stat-strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:24px}
    .stat-card{background:var(--bg-card);border:1px solid var(--gray-3);border-radius:var(--radius);padding:16px 18px;display:flex;flex-direction:column;gap:4px}
    .stat-card .stat-val{font-family:'Barlow Condensed',sans-serif;font-size:32px;font-weight:700;color:var(--green);line-height:1}
    .stat-card .stat-lbl{font-size:11px;color:var(--gray-2);text-transform:uppercase;letter-spacing:.08em}
    .table-wrap{overflow-x:auto;border-radius:var(--radius);border:1px solid var(--gray-3)}
    table{width:100%;border-collapse:collapse;font-size:13.5px}
    thead tr{background:var(--bg-deep)}
    th{padding:11px 14px;text-align:left;font-family:'Barlow Condensed',sans-serif;font-size:12px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--green);white-space:nowrap;border-bottom:1px solid var(--gray-3)}
    td{padding:10px 14px;border-bottom:1px solid rgba(255,255,255,.04);color:var(--gray-1);vertical-align:middle}
    tbody tr:last-child td{border-bottom:none}
    tbody tr:hover{background:rgba(255,255,255,.025)}
    .pill{display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600;letter-spacing:.05em;text-transform:uppercase}
    .pill-green{background:rgba(141,198,63,.18);color:#a8d96b}.pill-yellow{background:rgba(255,210,60,.15);color:#f5c842}
    .pill-blue{background:rgba(90,160,240,.15);color:#7bb8f8}.pill-red{background:rgba(240,80,80,.15);color:#f57a7a}
    .pill-gray{background:rgba(150,150,150,.15);color:#aaa}.pill-orange{background:rgba(240,150,50,.15);color:#f5a050}
    .filter-bar{display:flex;gap:10px;align-items:center;margin-bottom:16px;flex-wrap:wrap}
    .search-box{display:flex;align-items:center;background:var(--bg-deep);border:1px solid var(--gray-3);border-radius:var(--radius);padding:0 12px;gap:8px;flex:1;min-width:200px;max-width:340px}
    .search-box input{background:none;border:none;outline:none;color:var(--white);font-family:'Barlow',sans-serif;font-size:13px;padding:8px 0;width:100%}
    .search-box input::placeholder{color:var(--gray-2)}
    select.filter-select{background:var(--bg-deep);border:1px solid var(--gray-3);border-radius:var(--radius);color:var(--gray-1);font-family:'Barlow',sans-serif;font-size:13px;padding:8px 12px;outline:none;cursor:pointer}
    select.filter-select:focus{border-color:var(--green)}
    .contact-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px}
    .contact-card{background:var(--bg-card);border:1px solid var(--gray-3);border-radius:var(--radius);padding:18px 20px;transition:border-color .15s}
    .contact-card:hover{border-color:var(--green-dim)}
    .contact-card .cc-name{font-weight:600;font-size:15px;color:var(--white);margin-bottom:2px}
    .contact-card .cc-company{font-size:12px;color:var(--green);text-transform:uppercase;letter-spacing:.08em;margin-bottom:10px}
    .contact-card .cc-row{display:flex;align-items:center;gap:7px;font-size:13px;color:var(--gray-1);margin-bottom:4px}
    .contact-card .cc-tag{display:inline-block;margin-top:10px;font-size:11px;padding:2px 8px;border-radius:20px;background:var(--green-glow);color:var(--green);border:1px solid rgba(141,198,63,.3)}
    .model-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px}
    .model-card{background:var(--bg-card);border:1px solid var(--gray-3);border-radius:var(--radius);overflow:hidden;transition:border-color .15s,transform .15s}
    .model-card:hover{border-color:var(--green-dim);transform:translateY(-2px)}
    .model-thumb{height:100px;background:linear-gradient(135deg,#2e3828 0%,#1a2010 100%);display:flex;align-items:center;justify-content:center;font-size:36px;color:var(--green-dim);border-bottom:1px solid var(--gray-3)}
    .model-info{padding:14px 16px}
    .model-info .model-name{font-family:'Barlow Condensed',sans-serif;font-weight:700;font-size:18px;color:var(--white);letter-spacing:.04em}
    .model-info .model-meta{font-size:12px;color:var(--gray-2);margin-top:2px}
    .model-info .model-specs{display:flex;gap:12px;margin-top:10px;flex-wrap:wrap}
    .model-spec{font-size:12px;color:var(--gray-1)}.model-spec strong{color:var(--green)}
    footer{background:var(--bg-deep);border-top:1px solid var(--gray-3);text-align:center;padding:18px 32px;font-size:12px;color:var(--gray-2)}
    footer span{color:var(--green)}
    @media(max-width:680px){header{padding:0 16px}.main{padding:20px 16px 48px}.panel-header{flex-direction:column;align-items:flex-start;gap:12px}.stat-strip{grid-template-columns:1fr 1fr}}
  </style>
</head>
<body>
<header>
  <a class="logo" href="#">
    <svg class="logo-icon" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
      <polygon points="22,4 42,22 2,22" fill="#8DC63F"/>
      <polygon points="22,9 23.2,12.6 27,12.6 24,14.8 25.2,18.4 22,16.2 18.8,18.4 20,14.8 17,12.6 20.8,12.6" fill="#FFFFFF" opacity="0.95"/>
      <rect x="7" y="22" width="30" height="18" rx="1" fill="#3A3A3A"/>
      <rect x="18" y="30" width="8" height="10" rx="1" fill="#8DC63F" opacity="0.75"/>
      <rect x="9" y="25" width="6" height="5" rx="1" fill="#8DC63F" opacity="0.4"/>
      <rect x="29" y="25" width="6" height="5" rx="1" fill="#8DC63F" opacity="0.4"/>
    </svg>
    <div class="logo-text">
      <span class="marathon">Marathon</span>
      <span class="homes">Homes</span>
    </div>
  </a>
  <div class="header-meta"><strong>Operations Portal</strong><br>Manufactured Homes Division</div>
</header>
<div class="tab-bar-wrapper">
  <div class="tab-bar" role="tablist">
    <button class="tab-btn active" data-tab="finance">💼 Finance Contacts</button>
    <button class="tab-btn" data-tab="dealer">📋 Dealer Licenses</button>
    <button class="tab-btn" data-tab="serial">🔢 Serial Log</button>
    <button class="tab-btn" data-tab="orders">✅ Confirmed Orders</button>
    <button class="tab-btn" data-tab="production">🏭 Production Schedule</button>
    <button class="tab-btn" data-tab="rework">🔧 Rework Homes</button>
    <button class="tab-btn" data-tab="yard">🏘 Yard Homes</button>
    <button class="tab-btn" data-tab="shipping">🚚 Shipping</button>
    <button class="tab-btn" data-tab="accounting">💰 Accounting</button>
    <button class="tab-btn" data-tab="models">🏠 Model List</button>
  </div>
</div>
<main class="main">
  <section class="tab-panel active" id="tab-finance">
    <div class="panel-header"><div><div class="panel-title">Finance <span>Contacts</span></div><div class="panel-subtitle">Lender representatives &amp; finance partners</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export</button><button class="btn btn-primary">＋ Add Contact</button></div></div>
    <div class="filter-bar"><div class="search-box"><span>🔍</span><input type="text" placeholder="Search contacts…"/></div><select class="filter-select"><option>All Lenders</option><option>21st Mortgage</option><option>Vanderbilt</option><option>Triad</option></select></div>
    <div class="contact-grid">
      <div class="contact-card"><div class="cc-name">Jamie Holloway</div><div class="cc-company">21st Mortgage</div><div class="cc-row"><span>📞</span>(800) 955-0021</div><div class="cc-row"><span>✉️</span>j.holloway@21stmortgage.com</div><div class="cc-row"><span>📍</span>Knoxville, TN</div><span class="cc-tag">Retail Lending</span></div>
      <div class="contact-card"><div class="cc-name">Renee Castillo</div><div class="cc-company">Vanderbilt Mortgage</div><div class="cc-row"><span>📞</span>(800) 970-7250</div><div class="cc-row"><span>✉️</span>r.castillo@vmf.com</div><div class="cc-row"><span>📍</span>Maryville, TN</div><span class="cc-tag">Retail Lending</span></div>
      <div class="contact-card"><div class="cc-name">Marcus Webb</div><div class="cc-company">Triad Financial Services</div><div class="cc-row"><span>📞</span>(888) 464-2677</div><div class="cc-row"><span>✉️</span>m.webb@triadfs.com</div><div class="cc-row"><span>📍</span>Jacksonville, FL</div><span class="cc-tag">Chattel Lending</span></div>
      <div class="contact-card"><div class="cc-name">Tanya Burns</div><div class="cc-company">Cascade Financial</div><div class="cc-row"><span>📞</span>(800) 731-2230</div><div class="cc-row"><span>✉️</span>t.burns@cascadelending.com</div><div class="cc-row"><span>📍</span>Kennewick, WA</div><span class="cc-tag">Land-Home</span></div>
    </div>
  </section>
  <section class="tab-panel" id="tab-dealer">
    <div class="panel-header"><div><div class="panel-title">Dealer <span>License Information</span></div><div class="panel-subtitle">Active, pending &amp; expired dealer licenses</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export CSV</button><button class="btn btn-primary">＋ Add Dealer</button></div></div>
    <div class="stat-strip"><div class="stat-card"><div class="stat-val">42</div><div class="stat-lbl">Active</div></div><div class="stat-card"><div class="stat-val">7</div><div class="stat-lbl">Pending Renewal</div></div><div class="stat-card"><div class="stat-val">3</div><div class="stat-lbl">Expired</div></div><div class="stat-card"><div class="stat-val">52</div><div class="stat-lbl">Total Dealers</div></div></div>
    <div class="filter-bar"><div class="search-box"><span>🔍</span><input type="text" placeholder="Search dealers…"/></div><select class="filter-select"><option>All States</option><option>TX</option><option>OK</option><option>NM</option><option>LA</option><option>AR</option></select><select class="filter-select"><option>All Statuses</option><option>Active</option><option>Pending</option><option>Expired</option></select></div>
    <div class="table-wrap"><table><thead><tr><th>Dealer Name</th><th>License #</th><th>State</th><th>Expiration</th><th>Status</th><th>Actions</th></tr></thead><tbody>
      <tr><td>Lone Star Homes</td><td>TX-DL-00412</td><td>TX</td><td>12/31/2025</td><td><span class="pill pill-green">Active</span></td><td><button class="btn btn-ghost" style="padding:4px 10px;font-size:12px">Edit</button></td></tr>
      <tr><td>Red River Housing</td><td>OK-DL-00887</td><td>OK</td><td>03/15/2026</td><td><span class="pill pill-yellow">Renewal Soon</span></td><td><button class="btn btn-ghost" style="padding:4px 10px;font-size:12px">Edit</button></td></tr>
      <tr><td>Desert Mesa Homes</td><td>NM-DL-00231</td><td>NM</td><td>09/01/2025</td><td><span class="pill pill-red">Expired</span></td><td><button class="btn btn-ghost" style="padding:4px 10px;font-size:12px">Edit</button></td></tr>
      <tr><td>Gulf Coast Dwellings</td><td>LA-DL-00564</td><td>LA</td><td>06/30/2026</td><td><span class="pill pill-green">Active</span></td><td><button class="btn btn-ghost" style="padding:4px 10px;font-size:12px">Edit</button></td></tr>
      <tr><td>Razorback Realty</td><td>AR-DL-00118</td><td>AR</td><td>11/30/2025</td><td><span class="pill pill-yellow">Renewal Soon</span></td><td><button class="btn btn-ghost" style="padding:4px 10px;font-size:12px">Edit</button></td></tr>
    </tbody></table></div>
  </section>
  <section class="tab-panel" id="tab-serial">
    <div class="panel-header"><div><div class="panel-title">Serial <span>Number Log</span></div><div class="panel-subtitle">Unit serial tracking — format 01-BRK####-26</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export</button><button class="btn btn-primary">＋ Log Serial</button></div></div>
    <div class="filter-bar"><div class="search-box"><span>🔍</span><input type="text" placeholder="Search serial…"/></div><select class="filter-select"><option>All Models</option><option>Terra</option><option>Azalea</option><option>Grayson</option><option>Brewster</option><option>Maverick</option><option>Stonewall</option><option>Liberty</option></select></div>
    <div class="table-wrap"><table><thead><tr><th>Serial #</th><th>Model</th><th>Section</th><th>Date Logged</th><th>Status</th><th>Dealer</th></tr></thead><tbody>
      <tr><td>01-BRK0142-26</td><td>Terra</td><td>A/B</td><td>06/02/2026</td><td><span class="pill pill-green">Complete</span></td><td>Lone Star Homes</td></tr>
      <tr><td>01-BRK0143-26</td><td>Azalea</td><td>A/B</td><td>06/03/2026</td><td><span class="pill pill-blue">In Production</span></td><td>Gulf Coast Dwellings</td></tr>
      <tr><td>01-BRK0144-26</td><td>Grayson</td><td>A</td><td>06/04/2026</td><td><span class="pill pill-yellow">Pending VOG</span></td><td>Red River Housing</td></tr>
      <tr><td>01-BRK0145-26</td><td>Brewster</td><td>A/B/C</td><td>06/05/2026</td><td><span class="pill pill-blue">In Production</span></td><td>Desert Mesa Homes</td></tr>
      <tr><td>01-BRK0146-26</td><td>Liberty</td><td>A/B</td><td>06/06/2026</td><td><span class="pill pill-gray">Scheduled</span></td><td>Razorback Realty</td></tr>
    </tbody></table></div>
  </section>
  <section class="tab-panel" id="tab-orders">
    <div class="panel-header"><div><div class="panel-title">Confirmed <span>Orders</span></div><div class="panel-subtitle">Active purchase orders &amp; dealer commitments</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export</button><button class="btn btn-primary">＋ New Order</button></div></div>
    <div class="stat-strip"><div class="stat-card"><div class="stat-val">28</div><div class="stat-lbl">Open Orders</div></div><div class="stat-card"><div class="stat-val">14</div><div class="stat-lbl">In Production</div></div><div class="stat-card"><div class="stat-val">6</div><div class="stat-lbl">Ready to Ship</div></div><div class="stat-card"><div class="stat-val">$4.2M</div><div class="stat-lbl">Backlog Value</div></div></div>
    <div class="table-wrap"><table><thead><tr><th>Order #</th><th>Dealer</th><th>Model</th><th>Config</th><th>Order Date</th><th>Est. Complete</th><th>Status</th></tr></thead><tbody>
      <tr><td>MH-2026-0881</td><td>Lone Star Homes</td><td>Terra 28×60</td><td>3BR/2BA</td><td>05/14/2026</td><td>07/08/2026</td><td><span class="pill pill-blue">In Production</span></td></tr>
      <tr><td>MH-2026-0882</td><td>Gulf Coast Dwellings</td><td>Maverick 32×76</td><td>4BR/2BA</td><td>05/18/2026</td><td>07/15/2026</td><td><span class="pill pill-blue">In Production</span></td></tr>
      <tr><td>MH-2026-0883</td><td>Red River Housing</td><td>Azalea 26×52</td><td>3BR/2BA</td><td>05/22/2026</td><td>07/20/2026</td><td><span class="pill pill-yellow">Pending</span></td></tr>
      <tr><td>MH-2026-0884</td><td>Desert Mesa Homes</td><td>Stonewall 28×56</td><td>3BR/2BA</td><td>06/01/2026</td><td>08/01/2026</td><td><span class="pill pill-gray">Scheduled</span></td></tr>
      <tr><td>MH-2026-0885</td><td>Razorback Realty</td><td>Liberty 32×80</td><td>4BR/3BA</td><td>06/05/2026</td><td>08/10/2026</td><td><span class="pill pill-green">Ready to Ship</span></td></tr>
    </tbody></table></div>
  </section>
  <section class="tab-panel" id="tab-production">
    <div class="panel-header"><div><div class="panel-title">Production <span>Schedule</span></div><div class="panel-subtitle">Live build queue — all active units</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export</button><button class="btn btn-primary">＋ Add Unit</button></div></div>
    <div class="stat-strip"><div class="stat-card"><div class="stat-val">47</div><div class="stat-lbl">Active Builds</div></div><div class="stat-card"><div class="stat-val">12</div><div class="stat-lbl">This Week</div></div><div class="stat-card"><div class="stat-val">9</div><div class="stat-lbl">VOG Complete</div></div><div class="stat-card"><div class="stat-val">5</div><div class="stat-lbl">Awaiting T&amp;T</div></div></div>
    <div class="filter-bar"><div class="search-box"><span>🔍</span><input type="text" placeholder="Search unit or dealer…"/></div><select class="filter-select"><option>All Months</option><option>June 2026</option><option>July 2026</option><option>August 2026</option></select><select class="filter-select"><option>All Statuses</option><option>Scheduled</option><option>In Production</option><option>VOG Complete</option><option>T&amp;T Pending</option></select></div>
    <div class="table-wrap"><table><thead><tr><th>Serial #</th><th>Model</th><th>Dealer</th><th>Sched. Date</th><th>VOG</th><th>T&amp;T</th><th>MCO</th><th>Status</th></tr></thead><tbody>
      <tr><td>01-BRK0142-26</td><td>Terra 28×60</td><td>Lone Star Homes</td><td>06/10/2026</td><td><span class="pill pill-green">✓</span></td><td><span class="pill pill-green">✓</span></td><td><span class="pill pill-green">✓</span></td><td><span class="pill pill-green">Complete</span></td></tr>
      <tr><td>01-BRK0143-26</td><td>Azalea 26×52</td><td>Gulf Coast</td><td>06/14/2026</td><td><span class="pill pill-green">✓</span></td><td><span class="pill pill-yellow">Pending</span></td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-blue">In Production</span></td></tr>
      <tr><td>01-BRK0144-26</td><td>Grayson 32×68</td><td>Red River</td><td>06/18/2026</td><td><span class="pill pill-yellow">Pending</span></td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-yellow">VOG Pending</span></td></tr>
      <tr><td>01-BRK0145-26</td><td>Brewster 28×52</td><td>Desert Mesa</td><td>06/22/2026</td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-gray">Scheduled</span></td></tr>
      <tr><td>01-BRK0146-26</td><td>Liberty 32×80</td><td>Razorback</td><td>07/01/2026</td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-gray">—</span></td><td><span class="pill pill-gray">Scheduled</span></td></tr>
    </tbody></table></div>
  </section>
  <section class="tab-panel" id="tab-rework">
    <div class="panel-header"><div><div class="panel-title">Rework <span>Homes</span></div><div class="panel-subtitle">Units flagged for inspection, repair, or correction</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export</button><button class="btn btn-primary">＋ Flag Unit</button></div></div>
    <div class="stat-strip"><div class="stat-card"><div class="stat-val">8</div><div class="stat-lbl">Open Reworks</div></div><div class="stat-card"><div class="stat-val">3</div><div class="stat-lbl">In Progress</div></div><div class="stat-card"><div class="stat-val">2</div><div class="stat-lbl">Awaiting Parts</div></div><div class="stat-card"><div class="stat-val">18</div><div class="stat-lbl">Closed YTD</div></div></div>
    <div class="table-wrap"><table><thead><tr><th>Serial #</th><th>Model</th><th>Issue Category</th><th>Flagged Date</th><th>Assigned Tech</th><th>Priority</th><th>Status</th></tr></thead><tbody>
      <tr><td>01-BRK0138-26</td><td>Maverick 32×76</td><td>Roof Decking</td><td>06/01/2026</td><td>J. Martinez</td><td><span class="pill pill-red">High</span></td><td><span class="pill pill-blue">In Progress</span></td></tr>
      <tr><td>01-BRK0135-26</td><td>Terra 28×60</td><td>HVAC Ductwork</td><td>06/03/2026</td><td>T. Williams</td><td><span class="pill pill-orange">Medium</span></td><td><span class="pill pill-yellow">Awaiting Parts</span></td></tr>
      <tr><td>01-BRK0130-26</td><td>Grayson 32×68</td><td>Exterior Siding</td><td>05/28/2026</td><td>B. Thompson</td><td><span class="pill pill-orange">Medium</span></td><td><span class="pill pill-blue">In Progress</span></td></tr>
      <tr><td>01-BRK0129-26</td><td>Liberty 32×80</td><td>Plumbing Rough-In</td><td>05/25/2026</td><td>Unassigned</td><td><span class="pill pill-red">High</span></td><td><span class="pill pill-yellow">Open</span></td></tr>
    </tbody></table></div>
  </section>
  <section class="tab-panel" id="tab-yard">
    <div class="panel-header"><div><div class="panel-title">Yard <span>Homes</span></div><div class="panel-subtitle">Completed units staged at the facility yard</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export</button><button class="btn btn-primary">＋ Add to Yard</button></div></div>
    <div class="stat-strip"><div class="stat-card"><div class="stat-val">16</div><div class="stat-lbl">Units in Yard</div></div><div class="stat-card"><div class="stat-val">9</div><div class="stat-lbl">Sold – Awaiting Ship</div></div><div class="stat-card"><div class="stat-val">7</div><div class="stat-lbl">Available</div></div><div class="stat-card"><div class="stat-val">34</div><div class="stat-lbl">Days Avg. Lot Time</div></div></div>
    <div class="table-wrap"><table><thead><tr><th>Serial #</th><th>Model</th><th>Config</th><th>Date Completed</th><th>Lot Location</th><th>Availability</th><th>Days in Yard</th></tr></thead><tbody>
      <tr><td>01-BRK0120-26</td><td>Stonewall 28×56</td><td>3BR/2BA</td><td>05/15/2026</td><td>Lot A-12</td><td><span class="pill pill-green">Available</span></td><td>40</td></tr>
      <tr><td>01-BRK0121-26</td><td>Terra 28×60</td><td>3BR/2BA</td><td>05/18/2026</td><td>Lot B-04</td><td><span class="pill pill-blue">Sold – Ship Pending</span></td><td>37</td></tr>
      <tr><td>01-BRK0122-26</td><td>Azalea 26×52</td><td>2BR/2BA</td><td>05/20/2026</td><td>Lot A-08</td><td><span class="pill pill-green">Available</span></td><td>35</td></tr>
      <tr><td>01-BRK0123-26</td><td>Maverick 32×76</td><td>4BR/2BA</td><td>05/28/2026</td><td>Lot C-02</td><td><span class="pill pill-blue">Sold – Ship Pending</span></td><td>27</td></tr>
      <tr><td>01-BRK0124-26</td><td>Liberty 32×80</td><td>4BR/3BA</td><td>06/01/2026</td><td>Lot B-11</td><td><span class="pill pill-green">Available</span></td><td>23</td></tr>
    </tbody></table></div>
  </section>
  <section class="tab-panel" id="tab-shipping">
    <div class="panel-header"><div><div class="panel-title">Shipping <span>Schedule</span></div><div class="panel-subtitle">Outbound transport logistics &amp; carrier tracking</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export</button><button class="btn btn-primary">＋ Schedule Shipment</button></div></div>
    <div class="stat-strip"><div class="stat-card"><div class="stat-val">5</div><div class="stat-lbl">Shipping This Week</div></div><div class="stat-card"><div class="stat-val">11</div><div class="stat-lbl">Pending Dispatch</div></div><div class="stat-card"><div class="stat-val">3</div><div class="stat-lbl">In Transit</div></div><div class="stat-card"><div class="stat-val">29</div><div class="stat-lbl">Delivered YTD</div></div></div>
    <div class="table-wrap"><table><thead><tr><th>Serial #</th><th>Model</th><th>Destination</th><th>Carrier</th><th>Dispatch Date</th><th>ETA</th><th>Status</th></tr></thead><tbody>
      <tr><td>01-BRK0121-26</td><td>Terra 28×60</td><td>Lubbock, TX</td><td>Pilgrim Transport</td><td>06/24/2026</td><td>06/26/2026</td><td><span class="pill pill-green">Confirmed</span></td></tr>
      <tr><td>01-BRK0123-26</td><td>Maverick 32×76</td><td>Baton Rouge, LA</td><td>Cross-Country Hauling</td><td>06/25/2026</td><td>06/28/2026</td><td><span class="pill pill-green">Confirmed</span></td></tr>
      <tr><td>01-BRK0115-26</td><td>Brewster 28×52</td><td>Tulsa, OK</td><td>Nationwide HH</td><td>06/20/2026</td><td>—</td><td><span class="pill pill-blue">In Transit</span></td></tr>
      <tr><td>01-BRK0110-26</td><td>Grayson 32×68</td><td>Albuquerque, NM</td><td>Pilgrim Transport</td><td>06/18/2026</td><td>—</td><td><span class="pill pill-blue">In Transit</span></td></tr>
      <tr><td>01-BRK0125-26</td><td>Stonewall 28×56</td><td>Fayetteville, AR</td><td>TBD</td><td>07/02/2026</td><td>07/05/2026</td><td><span class="pill pill-yellow">Pending</span></td></tr>
    </tbody></table></div>
  </section>
  <section class="tab-panel" id="tab-accounting">
    <div class="panel-header"><div><div class="panel-title">Accounting <span>Overview</span></div><div class="panel-subtitle">Invoices, payments, and financial tracking</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Export</button><button class="btn btn-primary">＋ New Invoice</button></div></div>
    <div class="stat-strip"><div class="stat-card"><div class="stat-val">$1.8M</div><div class="stat-lbl">Open Receivables</div></div><div class="stat-card"><div class="stat-val">$642K</div><div class="stat-lbl">Invoiced This Month</div></div><div class="stat-card"><div class="stat-val">$318K</div><div class="stat-lbl">Overdue &gt;30 Days</div></div><div class="stat-card"><div class="stat-val">14</div><div class="stat-lbl">Pending Invoices</div></div></div>
    <div class="table-wrap"><table><thead><tr><th>Invoice #</th><th>Dealer</th><th>Serial #</th><th>Invoice Date</th><th>Amount</th><th>Due Date</th><th>Status</th></tr></thead><tbody>
      <tr><td>INV-2026-0441</td><td>Lone Star Homes</td><td>01-BRK0142-26</td><td>06/10/2026</td><td>$87,500</td><td>07/10/2026</td><td><span class="pill pill-yellow">Open</span></td></tr>
      <tr><td>INV-2026-0440</td><td>Gulf Coast Dwellings</td><td>01-BRK0140-26</td><td>06/05/2026</td><td>$102,000</td><td>07/05/2026</td><td><span class="pill pill-yellow">Open</span></td></tr>
      <tr><td>INV-2026-0438</td><td>Red River Housing</td><td>01-BRK0136-26</td><td>05/28/2026</td><td>$74,250</td><td>06/27/2026</td><td><span class="pill pill-red">Overdue</span></td></tr>
      <tr><td>INV-2026-0430</td><td>Desert Mesa Homes</td><td>01-BRK0130-26</td><td>05/10/2026</td><td>$95,800</td><td>06/09/2026</td><td><span class="pill pill-red">Overdue</span></td></tr>
      <tr><td>INV-2026-0425</td><td>Razorback Realty</td><td>01-BRK0124-26</td><td>04/22/2026</td><td>$118,400</td><td>05/22/2026</td><td><span class="pill pill-green">Paid</span></td></tr>
    </tbody></table></div>
  </section>
  <section class="tab-panel" id="tab-models">
    <div class="panel-header"><div><div class="panel-title">Model List <span>&amp; Floorplans</span></div><div class="panel-subtitle">Current manufactured home catalog</div></div><div class="btn-row"><button class="btn btn-ghost">⬇ Catalog PDF</button><button class="btn btn-primary">＋ Add Model</button></div></div>
    <div class="filter-bar"><div class="search-box"><span>🔍</span><input type="text" placeholder="Search models…"/></div><select class="filter-select"><option>All Widths</option><option>Single Wide</option><option>Double Wide</option><option>Triple Wide</option></select></div>
    <div class="model-grid">
      <div class="model-card"><div class="model-thumb">🏠</div><div class="model-info"><div class="model-name">Terra</div><div class="model-meta">Double Wide — 28×60</div><div class="model-specs"><div class="model-spec"><strong>3</strong> BR</div><div class="model-spec"><strong>2</strong> BA</div><div class="model-spec"><strong>1,680</strong> sq ft</div></div><button class="btn btn-ghost" style="margin-top:12px;width:100%;justify-content:center;font-size:12px">View Floorplan</button></div></div>
      <div class="model-card"><div class="model-thumb">🏠</div><div class="model-info"><div class="model-name">Azalea</div><div class="model-meta">Double Wide — 26×52</div><div class="model-specs"><div class="model-spec"><strong>3</strong> BR</div><div class="model-spec"><strong>2</strong> BA</div><div class="model-spec"><strong>1,352</strong> sq ft</div></div><button class="btn btn-ghost" style="margin-top:12px;width:100%;justify-content:center;font-size:12px">View Floorplan</button></div></div>
      <div class="model-card"><div class="model-thumb">🏠</div><div class="model-info"><div class="model-name">Grayson</div><div class="model-meta">Double Wide — 32×68</div><div class="model-specs"><div class="model-spec"><strong>4</strong> BR</div><div class="model-spec"><strong>2</strong> BA</div><div class="model-spec"><strong>2,176</strong> sq ft</div></div><button class="btn btn-ghost" style="margin-top:12px;width:100%;justify-content:center;font-size:12px">View Floorplan</button></div></div>
      <div class="model-card"><div class="model-thumb">🏠</div><div class="model-info"><div class="model-name">Brewster</div><div class="model-meta">Double Wide — 28×52</div><div class="model-specs"><div class="model-spec"><strong>3</strong> BR</div><div class="model-spec"><strong>2</strong> BA</div><div class="model-spec"><strong>1,456</strong> sq ft</div></div><button class="btn btn-ghost" style="margin-top:12px;width:100%;justify-content:center;font-size:12px">View Floorplan</button></div></div>
      <div class="model-card"><div class="model-thumb">🏠</div><div class="model-info"><div class="model-name">Maverick</div><div class="model-meta">Double Wide — 32×76</div><div class="model-specs"><div class="model-spec"><strong>4</strong> BR</div><div class="model-spec"><strong>2</strong> BA</div><div class="model-spec"><strong>2,432</strong> sq ft</div></div><button class="btn btn-ghost" style="margin-top:12px;width:100%;justify-content:center;font-size:12px">View Floorplan</button></div></div>
      <div class="model-card"><div class="model-thumb">🏠</div><div class="model-info"><div class="model-name">Stonewall</div><div class="model-meta">Double Wide — 28×56</div><div class="model-specs"><div class="model-spec"><strong>3</strong> BR</div><div class="model-spec"><strong>2</strong> BA</div><div class="model-spec"><strong>1,568</strong> sq ft</div></div><button class="btn btn-ghost" style="margin-top:12px;width:100%;justify-content:center;font-size:12px">View Floorplan</button></div></div>
      <div class="model-card"><div class="model-thumb">🏠</div><div class="model-info"><div class="model-name">Liberty</div><div class="model-meta">Triple Wide — 32×80</div><div class="model-specs"><div class="model-spec"><strong>4</strong> BR</div><div class="model-spec"><strong>3</strong> BA</div><div class="model-spec"><strong>2,560</strong> sq ft</div></div><button class="btn btn-ghost" style="margin-top:12px;width:100%;justify-content:center;font-size:12px">View Floorplan</button></div></div>
    </div>
  </section>
</main>
<footer>© 2026 <span>Marathon Homes</span> — Operations Portal &nbsp;|&nbsp; Internal Use Only</footer>
<script>
const tabs={finance:'tab-finance',dealer:'tab-dealer',serial:'tab-serial',orders:'tab-orders',production:'tab-production',rework:'tab-rework',yard:'tab-yard',shipping:'tab-shipping',accounting:'tab-accounting',models:'tab-models'};
document.querySelectorAll('.tab-btn').forEach(btn=>{btn.addEventListener('click',()=>{const key=btn.dataset.tab;document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));btn.classList.add('active');document.getElementById(tabs[key])?.classList.add('active')})});
</script>
</body>
</html>
HTMLEOF

echo "→ Creating .gitignore"
cat > .gitignore << 'EOF'
.DS_Store
Thumbs.db
*.log
node_modules/
EOF

echo "→ Creating README.md"
cat > README.md << 'EOF'
# Marathon Homes – Operations Portal

Internal single-page operations portal for Marathon Homes manufactured housing division.

## Structure
- `index.html` — Full portal (all 10 tabs in one file)

## Tabs
1. Finance Contacts
2. Dealer License Information
3. Serial Number Log
4. Confirmed Orders
5. Production Schedule
6. Rework Homes
7. Yard Homes
8. Shipping
9. Accounting
10. Model List / Floorplans

## Development
Open `index.html` directly in any browser — no build step required.
EOF

echo "→ Running initial git commit"
git add -A
git commit -m "feat: initial Marathon Homes Operations Portal landing page"

echo ""
echo "✅ Done! Files saved to: $PROJECT_DIR"
echo ""
echo "To open in browser, run:"
echo "   start index.html"
echo ""
echo "To push to GitHub, run:"
echo "   git remote add origin https://github.com/Barrettl89/marathonproduction.git"
echo "   git push -u origin main"
HTMLEOF
