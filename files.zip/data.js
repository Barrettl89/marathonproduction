/* ═══════════════════════════════════════════════════════════
   MARATHON HOMES — Operations Portal
   data.js — Central data store for all tabs
   ═══════════════════════════════════════════════════════════ */

'use strict';

// ── 1. Finance Contacts ─────────────────────────────────────
const financeContacts = [
  // { name: '', company: '', phone: '', email: '', type: '' }
];

// ── 2. Dealer License Information ───────────────────────────
const dealerLicenses = [
  // { dealer: '', licenseNumber: '', state: '', expiration: '', status: '' }
];

// ── 3. Serial Number Log ─────────────────────────────────────
const serialLog = [
  // { serial: '', model: '', dealer: '', mcoStatus: '', assignedDate: '' }
  // Serial format example: '01-BRK1234-26'
];

// ── 4. Confirmed Orders ──────────────────────────────────────
const confirmedOrders = [
  // { orderNum: '', dealer: '', model: '', serial: '', confirmedDate: '', status: '' }
];

// ── 5. Production Schedule ───────────────────────────────────
const productionSchedule = [
  // { serial: '', model: '', dealer: '', scheduledDate: '', completionDate: '', status: '', notes: '' }
  // Models: Terra, Azalea, Grayson, Brewster, Maverick, Stonewall, Liberty
];

// ── 6. Rework Homes ──────────────────────────────────────────
const reworkHomes = [
  // { serial: '', model: '', issue: '', assignedTo: '', dateIn: '', status: '' }
];

// ── 7. Yard Homes ────────────────────────────────────────────
const yardHomes = [
  // { serial: '', model: '', dealer: '', dateCompleted: '', yardLocation: '', status: '' }
];

// ── 8. Shipping ──────────────────────────────────────────────
const shipping = [
  // { serial: '', model: '', dealer: '', carrier: '', schedDate: '', ttStatus: '', deliveryConfirmed: '' }
  // ttStatus = T&T (Title and Tag)
];

// ── 9. Accounting ────────────────────────────────────────────
const accounting = [
  // { serial: '', dealer: '', invoiceNum: '', amount: '', floorplanPayoff: '', vogDate: '', paidDate: '' }
  // VOG = Vehicle on Grade
];

// ── 10. Model List / Floorplans ──────────────────────────────
const modelList = [
  // { model: '', sqft: '', bedrooms: '', bathrooms: '', basePrice: '', floorplanUrl: '' }
  // Known models: Terra, Azalea, Grayson, Brewster, Maverick, Stonewall, Liberty
];
