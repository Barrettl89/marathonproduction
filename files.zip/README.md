# Marathon Homes — Operations Portal

Internal web portal for manufacturing operations, shipping, accounting, and dealer management.

---

## Git Bash Setup (One-Time)

Run this in Git Bash to clone and initialize the project:

```bash
cd ~/Downloads
git clone https://github.com/YOUR_USERNAME/marathon-homes-portal.git
cd marathon-homes-portal
```

Or if starting from scratch (no repo yet):

```bash
mkdir -p ~/Downloads/marathon-homes-portal
cd ~/Downloads/marathon-homes-portal
git init
git remote add origin https://github.com/YOUR_USERNAME/marathon-homes-portal.git
```

---

## Project Structure

```
marathon-homes-portal/
├── index.html          ← Landing page (tabs, header, layout)
├── css/
│   └── style.css       ← All styles (palette, tabs, tables, pills)
├── js/
│   ├── app.js          ← Tab switching, date display, render hooks
│   └── data.js         ← Central data store — fill in your records here
└── README.md
```

---

## Tabs

| # | Tab ID               | Purpose                                    |
|---|----------------------|--------------------------------------------|
| 1 | finance-contacts     | Lender reps, floor-plan contacts           |
| 2 | dealer-license       | Dealer license numbers, expiration, status |
| 3 | serial-log           | Serial number assignments and MCO status   |
| 4 | confirmed-orders     | Orders confirmed for production            |
| 5 | production-schedule  | Manufacturing line schedule and status     |
| 6 | rework-homes         | Units flagged for rework                   |
| 7 | yard-homes           | Completed units staged in yard             |
| 8 | shipping             | Hauls, carriers, T&T, delivery status      |
| 9 | accounting           | Invoices, VOG, floor-plan payoffs          |
|10 | model-list           | Model catalog with specs and floorplans    |

---

## Color Palette

| Token        | Hex       | Use                        |
|--------------|-----------|----------------------------|
| `--bg-dark`  | `#2B2B2B` | Page background            |
| `--bg-card`  | `#3A3A3A` | Cards, panels              |
| `--green`    | `#8DC63F` | Accents, active tab, logo  |
| `--white`    | `#FFFFFF` | Primary text               |

---

## Workflow

1. Edit `js/data.js` to add records for any tab
2. Edit `index.html` to replace placeholder cards with real tables
3. Auto-push to GitHub after every session
