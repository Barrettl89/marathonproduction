/* ═══════════════════════════════════════════════════════════
   MARATHON HOMES — Operations Portal
   app.js — Tab navigation, live date, and rendering hooks
   ═══════════════════════════════════════════════════════════ */

'use strict';

// ── Tab Navigation ──────────────────────────────────────────
const tabButtons = document.querySelectorAll('.tab-btn');
const tabPanels  = document.querySelectorAll('.tab-panel');

function activateTab(targetId) {
  tabButtons.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === targetId);
  });
  tabPanels.forEach(panel => {
    panel.classList.toggle('active', panel.id === targetId);
  });
}

tabButtons.forEach(btn => {
  btn.addEventListener('click', () => activateTab(btn.dataset.tab));
});

// ── Live Date ────────────────────────────────────────────────
function updateDate() {
  const el = document.getElementById('live-date');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleDateString('en-US', {
    weekday: 'short', year: 'numeric', month: 'short', day: 'numeric'
  });
}
updateDate();

const yearEl = document.getElementById('footer-year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// ── Tab Render Hooks ─────────────────────────────────────────
// Each tab can register a render function here.
// Call renderTab('tab-id') after data is loaded.
const tabRenderers = {};

function registerRenderer(tabId, fn) {
  tabRenderers[tabId] = fn;
}

function renderTab(tabId) {
  if (tabRenderers[tabId]) {
    tabRenderers[tabId]();
  }
}

// ── Expose globals for future modules ────────────────────────
window.MarathonPortal = {
  activateTab,
  registerRenderer,
  renderTab,
};
